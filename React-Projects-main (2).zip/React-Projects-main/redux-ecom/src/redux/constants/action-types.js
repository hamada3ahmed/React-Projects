const ActionTypes = {
    ADD_PRODUCT: "ADD_PRODUCT",
    REMOVE_PRODUCT: "REMOVE_PRODUCT",
    DECREASE_QTY: "DECREASE_QTY"
}

export default ActionTypes;