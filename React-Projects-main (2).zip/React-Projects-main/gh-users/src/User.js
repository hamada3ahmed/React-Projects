import React from 'react'

const User = () => {
    return (
        <div>
            
        </div>
    )
}

export default User
